<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Assessor extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if($this->session->userdata('status') != 'login' ){
	    	redirect();
	    }
	    $this->load->model('User');

	}

	public function index()
	{
		$data['profil']=$this->User->get_where('user',['id' => $this->session->userdata('nip')])->result_array();
		$skor  =$this->User->get_where('skor_awal',['id_penilai' => $this->session->userdata('nip'),'skor' => ' '])->result_array();
		$data['skor'] = empty($skor)? 0  : 1; 
		// var_dump(isset($skor)) or die;
		$data['sesi'] = $this->User->get('buka')->result_array();		
		if ($this->session->userdata('level') == 'dosen') {

		$data['rata'] =$this->average_value();
		}

		// var_dump($data) or die;

		$this->load->view('header');

		if ($this->session->userdata('level') == 'dosen') {
		$this->load->view('assessor/dashboard',$data);			
		}
		else{
		$this->load->view('assessor/dashboard1',$data);			

		}
	}

	public function average_value()
	{
		$mahasiswa = $this->User->chart($this->session->userdata('nip'),'mahasiswa')->result_array();
		$dosen = $this->User->chart($this->session->userdata('nip'),'dosen')->result_array();
		$atasan = $this->User->chart($this->session->userdata('nip'),'atasan')->result_array();
		// var_dump($mahasiswa) ;
		$data['mahasiswa'] = ['kepribadian' => 0, 'pendagogik' => 0,'sosial' => 0,'jumlah' => 0] ;
		for ($i=0; $i < count($mahasiswa); $i++) {
			$a =$this->json($mahasiswa[$i]['skor'],'mahasiswa'); 
			$data['mahasiswa']['kepribadian'] += $a['kepribadian'] ;
			$data['mahasiswa']['pendagogik'] += $a['pendagogik'] ;
			$data['mahasiswa']['sosial'] += $a['sosial'] ;
			$data['mahasiswa']['jumlah']++;

		}

		$data['mahasiswa']['jumlah'] = $data['mahasiswa']['jumlah'] * 5;
		$data['mahasiswa']['kepribadian'] =  $data['mahasiswa']['kepribadian'] * 100 /$data['mahasiswa']['jumlah'];
		$data['mahasiswa']['pendagogik'] =  $data['mahasiswa']['pendagogik'] * 100 /$data['mahasiswa']['jumlah'];
		$data['mahasiswa']['sosial'] =  $data['mahasiswa']['sosial'] * 100 /$data['mahasiswa']['jumlah'];


		$data['dosen'] = ['kepribadian' => 0, 'pendagogik' => 0,'profesional' => 0,'sosial' => 0,'jumlah' => 0] ;

		for ($i=0; $i < count($dosen); $i++) { 
			$a =$this->json($dosen[$i]['skor'],'mahasiswa'); 
			$data['dosen']['kepribadian'] += $a['kepribadian'] ;
			$data['dosen']['pendagogik'] += $a['pendagogik'] ;
			$data['dosen']['profesional'] += $a['profesional'] ;
			$data['dosen']['sosial'] += $a['sosial'] ;
			$data['dosen']['jumlah']++;
			
		}

		$data['dosen']['jumlah'] = $data['dosen']['jumlah'] * 5;
		$data['dosen']['kepribadian'] =  $data['dosen']['kepribadian'] * 100 /$data['dosen']['jumlah'];
		$data['dosen']['pendagogik'] =  $data['dosen']['pendagogik'] * 100 /$data['dosen']['jumlah'];
		$data['dosen']['sosial'] =  $data['dosen']['sosial'] * 100 /$data['dosen']['jumlah'];
		$data['dosen']['profesional'] =  $data['dosen']['sosial'] * 100 /$data['dosen']['jumlah'];
		

		$data['atasan'] = ['kepribadian' => 0, 'profesional' => 0,'sosial' => 0,'jumlah' => 0] ;
		for ($i=0; $i < count($atasan); $i++) { 
			$data['atasan'] += $this->json($atasan[$i]['skor'],'atasan');			
			$data['atasan']['kepribadian'] += $a['kepribadian'] ;
			$data['atasan']['profesional'] += $a['profesional'] ;
			$data['atasan']['sosial'] += $a['sosial'] ;
			$data['atasan']['jumlah']++;

		}

		$data['atasan']['jumlah'] = $data['atasan']['jumlah'] * 5;
		$data['atasan']['kepribadian'] =  $data['atasan']['kepribadian'] * 100 /$data['atasan']['jumlah'];

		$data['atasan']['sosial'] =  $data['atasan']['sosial'] * 100 /$data['atasan']['jumlah'];
		$data['atasan']['profesional'] =  $data['atasan']['profesional'] * 100 /$data['atasan']['jumlah'];
		
		// var_dump($data)or die;
		return $data;
	}

public function json($value)
	{	
		$value = json_decode('['.$value.']' , 1);
		
		 // var_dump($value) or die;
			$data['kepribadian'] = 0;	
			$data['sosial'] 	 = 0;	
			if (isset($value[0]['pendagogik']) ) {
				$data['pendagogik']  = 0;	
			
			}
			if (isset($value[0]['profesional']) ) {
				$data['profesional'] = 0;	
			}
		
		for ($i=0; $i < count($value); $i++) { 
			$data['kepribadian'] += $value[$i]['kepribadian'];	
			if (isset($value[0]['pendagogik']) ) {
		
			$data['pendagogik']  += $value[$i]['pendagogik'];	
			}
			$data['sosial'] 	 += $value[$i]['sosial'];	
			if (isset($value[0]['profesional']) ) {
				$data['profesional'] +=  $value[$i]['profesional'];	
			}
		}
		$rata['kepribadian'] = $data['kepribadian'] / count($value);
		if (isset($value[0]['pendagogik']) ) {
	
		$rata['pendagogik'] = $data['pendagogik'] / count($value);
		}
		$rata['sosial'] = $data['sosial'] / count($value);
		if (isset($value[0]['profesional']) ) {
			$rata['profesional'] = $data['profesional'] / count($value);
		}	

		// var_dump($rata) or die;
		return $rata;
	}	

	public function chart()
	{

		$mahasiswa = $this->User->chart($this->session->userdata('nip'),'mahasiswa')->result_array();
		$dosen = $this->User->chart($this->session->userdata('nip'),'dosen')->result_array();
		$atasan = $this->User->chart($this->session->userdata('nip'),'atasan')->result_array();


		$data['mahasiswa'] = ['kepribdian' => [],'pendagogik' => [],'sosial' => []];
		$data['dosen'] = ['kepribdian' => [],'pendagogik' => [],'sosial' => []];
		$data['atasan'] = ['kepribdian' => [],'pendagogik' => [],'sosial' => []];
		for ($i=0; $i < count($mahasiswa) ; $i++) { 
			array_push($data['mahasiswa']['kepribdian'], $mahasiswa[$i]);  
		}
		// var_dump($mahasiswa) or die;


	}


	public function average()
	{
		$atasan  = $this->User->get_where('skor_awal','atasan')->result_array();
		$dosen  = $this->User->skor('dosen')->result_array();
		$mahasiswa  = $this->User->skor('mahasiswa')->result_array();
		
		$dosen1 = $this->User->get_where('kriteria',['level'=> 'rekan'])->result_array();
		$mahasiswa1 = $this->User->get_where('kriteria',['level'=> 'mahasiswa'])->result_array();
		$atasan1 = $this->User->get_where('kriteria',['level'=> 'atasan'])->result_array();
		
		$data ['bobot']['dosen'] = $dosen1;
		$data ['bobot']['mahasiswa'] = $mahasiswa1;
		$data ['bobot']['atasan'] = $atasan1;

		$data['mahasiswa'] = [] ;
		for ($i=0; $i < count($mahasiswa); $i++) { 
			$data['mahasiswa'][$i+1] =  $this->json($mahasiswa[$i]['skor'],'mahasiswa');
			$data['mahasiswa'][$i+1]['jumlah'] = $mahasiswa[$i]['jumlah'] ;
			$data['mahasiswa'][$i+1]['id'] = $mahasiswa[$i]['id_dosen'] ;
		}
		$data['dosen'] = [] ;
		for ($i=0; $i < count($dosen); $i++) { 
			$data['dosen'][$i+1] = $this->json($dosen[$i]['skor'],'dosen');
			$data['dosen'][$i+1]['jumlah'] = $dosen[$i]['jumlah'] ;
			$data['dosen'][$i+1]['id'] = $dosen[$i]['id_dosen'] ;

		}

		$data['atasan'] = [] ;
		for ($i=0; $i < count($atasan); $i++) { 
			$data['atasan'][$i+1]= $this->json($atasan[$i]['skor'],'atasan');
			$data['atasan'][$i+1]['jumlah'] = $atasan[$i]['jumlah'] ;
			$data['atasan'][$i+1]['id'] = $atasan[$i]['id_dosen'] ;

		}

		return $data;
	}

	public function password()
	{
		$password = md5($this->input->post('password'));
		$this->User->update('user',['password'=>$password],['id' => $this->session->userdata('nip')]);
		redirect('profil');
	}

	public function que()
	{
		$data['kue'] =$this->User->kue( intval($this->session->userdata('nip')))->result_array();
		$data['sesi'] = $this->User->get('buka')->result_array();		
		// var_dump($data) or die();
		$this->load->view('header');
		$this->load->view('assessor/que',$data);

	}	


	public function input($id)
	{
		$data['kue'] =$this->User->kriteria( $this->session->userdata('level'))->result_array();
		$data['id'] = $id;
		// var_dump($data) or die();
		$this->load->view('header');
		$this->load->view('assessor/input',$data);

	}

	public function input_action()
	{

		// $id = explode(',',$this->input->post('id'));
		$level =  $this->User->get_where('kriteria',['level' => $this->session->userdata('level')])->result_array();
		// var_dump($level) or die;
		$kri = [];
		$kriteria = [];
		foreach ($level as $key ) {
			array_push($kri ,$key['id']);
			array_push($kriteria ,$key['kriteria']);
		}

		for ($i=0; $i < count($kri); $i++) { 
			$kue[$i] = $this->User->get_where('kuesioner',['id_kriteria' => $kri[$i] ])->result_array();
			$id[$i] = [];
			foreach ($kue[$i] as $key ) {
				 array_push($id[$i], intval($key['id'])) ;
			}
			$sum[$i] = 0;
			for ($j=0; $j < count($id[$i]) ; $j++) { 
				$sum[$i] += $this->input->post($id[$i][$j]);
				// echo $sum[$i];
				$avg[$i] = $sum[$i] / count($id[$i]);
			}

			$data[$kriteria[$i]] = $avg[$i];  
			// $data['rata'][$i]['kriteria'] = ;  

		}
		$data = json_encode($data);
		$this->db->update('skor_awal', ['skor' => $data],['id' => intval($this->input->post('id'))]);
		var_dump($this->db->last_query());
		// redirect('pilih');
	}	


	// public function password()
	// {
	// 	$this->load->view('header');
	// 	$this->load->view('assessor/password');
	// }

	// public function change_password()
	// {
	// 	redirect('ganti');
	// }
}

/* End of file assessor.php */
/* Location: ./application/controllers/assessor.php */